﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HousTrace.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HousTrace.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SignUpPage : ContentPage
    {
        public SignUpPage()
        {
            InitializeComponent();
        }
       // string ema, pa, cpa;
        private async void BtnSignUp_OnClicked(object sender, EventArgs e)
        {
            BtnSignUp.Text = "جاري التسجيل ... ";
            //ema = EntEmail.Text;
            //pa = EntPassword.Text;
            //cpa = EntConfirmPassword.Text;
            ApiServices apiServices = new ApiServices();
            bool response = await apiServices.RegisterUser(EntEmail.Text, EntPassword.Text, EntConfirmPassword.Text);
            if (!response)
            {
               await DisplayAlert("تنبيه", "خطا في عملية الادخال" , "إلغاء");
            }
            else
            {
                await DisplayAlert("اهلا ومرحبا", "تم انشاء حسابك بنجاح", "موافق");
                await Navigation.PopToRootAsync();
            }
            BtnSignUp.Text = "تسجيل ";
        }
    }
}