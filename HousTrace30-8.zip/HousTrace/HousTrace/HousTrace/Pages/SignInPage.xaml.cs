﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HousTrace.Pages;
using HousTrace.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HousTrace.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SignInPage : ContentPage
    {
        public SignInPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);

        }

        //private async Task BtnLogin_ClickedAsync(object sender, EventArgs e)
        //{

        //}

        private void TapSignUp_Tapped(object sender, EventArgs e)
        {
               Navigation.PushAsync(new SignUpPage());
        }

        private async Task BtnLogin_Clicked(object sender, EventArgs e)
        {
            BtnLogin.Text = "انتظر...";
            ApiServices apiServices = new ApiServices();
            bool response = await apiServices.LoginUser(EntEmail.Text, EntPassword.Text);
            if (!response)
            {
                await DisplayAlert("تنبيه", "تاكد من اسم المستخدم او كلمة المرور", "إلغاء");
            }
            else
            {
                Navigation.InsertPageBefore(new HomePage(), this);
                await Navigation.PopAsync();
            }
            BtnLogin.Text = "دخول";
        }

        private async Task BtnExit_Clicked(object sender, EventArgs e)
        {
            var answer = await DisplayAlert("خروج", "هل تريد الخروج", "نعم", "لا");
            if (answer)
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();


                //_canClose = false;
                //OnBackButtonPressed;
            }
        }
    }
}